canfuel - poznamky k vyrobnim datum
===================================

Deska:   canfuel, 55 x 45 mm, 2 vrstvy, 1,5 mm
Data:    Gerbers.zip - Gerber RS-274X + Excellon (tento balik)
         Odb.zip     - ODB++, tataz deska, tataz revize
Revize:  git c06e710


PRUMERY OTVORU
--------------
Prokovene otvory (canfuel-PTH.drl, nastroje 0,30 / 0,80 / 0,90 / 1,00 /
1,02 mm) jsou uvedeny jako VYSLEDNE prumery po prokoveni.

Neprokovene otvory (canfuel-NPTH.drl, nastroje 3,00 a 3,20 mm) jsou
NEPROKOVENE, vrtany prumer = vysledny prumer.

Otvory 3,00 mm jsou pro plastove zamky konektoru Molex Micro-Fit 3.0
(43045-0400), J1 a J2. Tyto otvory NESMI byt prokoveny: predpis Molex
(vykres SD-43045-001) je 3,00 +/- 0,05 mm a prokoveni by je zmensilo
pod dolni mez, coz znemozni nasazeni konektoru.

Otvory 3,20 mm jsou montazni (M3), rovnez neprokovene.


TOLERANCE
---------
Standardni tolerance postacuje, uzsi tridu nepozadujeme.


DALSI
-----
- Bez rizene impedance, bez slepych a pohrbenych otvoru, bez mikrovias.
- Obrys frezovany na jednotlive kusy, bez drazkovani.
  Nejmensi radius na obrysu 2,0 mm.
- Nejuzsi spoj 0,25 mm, nejmensi izolacni mezera 0,20 mm.
- Med k hrane desky 0,30 mm.
- Potisk pouze TOP. Spodni potisk je v datech prilozen, ale obsahuje
  jedine oznaceni (C7) a neni pozadovan.
- Osazovaci sablona neni pozadovana.
- R5 je zamerne neosazeny rezistor (na potisku oznaceny "120R DNF").
  Na desce ma plosky a otvory, ktere maji byt vyrobeny normalne.
